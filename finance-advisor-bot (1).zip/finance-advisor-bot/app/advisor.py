"""AI advisor. Uses Claude if ANTHROPIC_API_KEY is set; otherwise a rule-based engine."""
import json
from flask import current_app


def rule_based_advice(summary, budget, flags, profile):
    tips = []
    if summary["total_income"] == 0:
        return ["Log your income for this month to unlock personalised advice."]
    if summary["savings_rate"] >= budget["split"]["savings"] * 100:
        tips.append("You hit your savings target this month. Consider moving the surplus into a goal.")
    tips.extend(flags["alerts"])
    if flags["wants_spent"] > budget["wants"]:
        tips.append("Pick your top two discretionary categories and set a weekly cap on each.")
    if profile == "student":
        tips.append("Track small recurring spends (snacks, subscriptions); they add up on a fixed allowance.")
    elif profile == "freelancer":
        tips.append("Budget from your lowest recent month, and top up an emergency fund in high-income months.")
    elif profile == "household":
        tips.append("Review utilities and groceries first; they are usually the easiest shared savings.")
    else:
        tips.append("Automate a transfer to savings on payday so saving happens before spending.")
    return tips


def llm_advice(summary, budget, flags, profile):
    key = current_app.config.get("ANTHROPIC_API_KEY")
    if not key:
        return None
    try:
        import anthropic
        client = anthropic.Anthropic(api_key=key)
        prompt = (
            "You are a concise personal finance advisor. Based on this data, give 3-5 specific, "
            "actionable tips as a JSON list of strings only.\n"
            f"Profile: {profile}\nSummary: {json.dumps(summary)}\n"
            f"Budget: {json.dumps(budget)}\nFlags: {json.dumps(flags)}"
        )
        msg = client.messages.create(
            model="claude-sonnet-5-5", max_tokens=600,
            messages=[{"role": "user", "content": prompt}],
        )
        text = msg.content[0].text.strip().strip("`")
        if text.startswith("json"):
            text = text[4:]
        tips = json.loads(text)
        return tips if isinstance(tips, list) else None
    except Exception:
        return None  # fall back silently to the rule-based engine


def get_advice(summary, budget, flags, profile):
    return llm_advice(summary, budget, flags, profile) or rule_based_advice(summary, budget, flags, profile)
