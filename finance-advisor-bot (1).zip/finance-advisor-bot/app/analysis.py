"""Financial analysis: monthly summaries, budget plans, overspending detection."""
from collections import defaultdict
from datetime import date
from statistics import mean
from .models import Income, Expense, ESSENTIAL


def month_bounds(year, month):
    start = date(year, month, 1)
    end = date(year + (month == 12), (month % 12) + 1, 1)
    return start, end


def monthly_summary(user_id, year, month):
    start, end = month_bounds(year, month)
    incomes = Income.query.filter(Income.user_id == user_id, Income.date >= start, Income.date < end).all()
    expenses = Expense.query.filter(Expense.user_id == user_id, Expense.date >= start, Expense.date < end).all()
    total_income = sum(i.amount for i in incomes)
    total_expense = sum(e.amount for e in expenses)
    by_cat = defaultdict(float)
    for e in expenses:
        by_cat[e.category] += e.amount
    savings = total_income - total_expense
    return {
        "year": year, "month": month,
        "total_income": round(total_income, 2),
        "total_expense": round(total_expense, 2),
        "savings": round(savings, 2),
        "savings_rate": round(savings / total_income * 100, 1) if total_income else 0.0,
        "by_category": dict(sorted(by_cat.items(), key=lambda kv: -kv[1])),
    }


def _prev_months(year, month, n):
    out = []
    for _ in range(n):
        month -= 1
        if month == 0:
            month, year = 12, year - 1
        out.append((year, month))
    return out


def income_baseline(user_id, year, month, profile):
    """Freelancers: budget off a conservative figure from recent months, not this month alone."""
    current = monthly_summary(user_id, year, month)["total_income"]
    if profile != "freelancer":
        return current
    past = [monthly_summary(user_id, y, m)["total_income"] for y, m in _prev_months(year, month, 3)]
    past = [p for p in past if p > 0]
    if not past:
        return current
    return round(min(mean(past), current) if current else mean(past) * 0.8, 2)


def generate_budget(income, profile):
    """Rule-based budget: 50/30/20 by default, adapted per profile."""
    splits = {
        "salaried": (0.50, 0.30, 0.20),
        "student": (0.60, 0.25, 0.15),
        "freelancer": (0.50, 0.20, 0.30),   # bigger savings buffer for lean months
        "household": (0.60, 0.20, 0.20),
    }
    needs, wants, save = splits.get(profile, splits["salaried"])
    return {
        "needs": round(income * needs, 2),
        "wants": round(income * wants, 2),
        "savings": round(income * save, 2),
        "split": {"needs": needs, "wants": wants, "savings": save},
    }


def detect_overspending(summary, budget):
    needs_spent = sum(v for c, v in summary["by_category"].items() if c in ESSENTIAL)
    wants_spent = sum(v for c, v in summary["by_category"].items() if c not in ESSENTIAL)
    alerts = []
    if needs_spent > budget["needs"]:
        alerts.append(f"Essentials are {needs_spent - budget['needs']:.2f} over budget.")
    if wants_spent > budget["wants"]:
        alerts.append(f"Discretionary spending is {wants_spent - budget['wants']:.2f} over budget.")
    if summary["savings"] < budget["savings"]:
        alerts.append(f"Savings are {budget['savings'] - summary['savings']:.2f} below target.")
    if summary["by_category"]:
        top, amt = next(iter(summary["by_category"].items()))
        if summary["total_expense"] and amt / summary["total_expense"] > 0.4:
            alerts.append(f"'{top}' makes up {amt / summary['total_expense'] * 100:.0f}% of your expenses.")
    return {"needs_spent": round(needs_spent, 2), "wants_spent": round(wants_spent, 2), "alerts": alerts}


def emergency_fund_target(summary):
    return round(summary["total_expense"] * 6, 2)


def lean_months(user_id, year, month, n=6):
    """Months where savings were negative or under 5% of income."""
    flagged = []
    y, m = year, month
    for _ in range(n):
        s = monthly_summary(user_id, y, m)
        if (s["total_income"] or s["total_expense"]) and s["savings_rate"] < 5:
            flagged.append(f"{y}-{m:02d}")
        m -= 1
        if m == 0:
            m, y = 12, y - 1
    return flagged
