from datetime import date, datetime
from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from flask_login import login_user, logout_user, login_required, current_user
from .models import db, User, Income, Expense, Goal, CATEGORIES, PROFILES
from .analysis import (monthly_summary, income_baseline, generate_budget,
                       detect_overspending, emergency_fund_target, lean_months)
from .advisor import get_advice

bp = Blueprint("main", __name__)


def _parse_date(s):
    try:
        return datetime.strptime(s, "%Y-%m-%d").date() if s else date.today()
    except ValueError:
        return date.today()


def _ym():
    today = date.today()
    try:
        year, month = int(request.args.get("year", today.year)), int(request.args.get("month", today.month))
        if not 1 <= month <= 12:
            raise ValueError
        return year, month
    except ValueError:
        return today.year, today.month


def _positive_amount(field="amount"):
    try:
        value = float(request.form[field])
        return value if value > 0 else None
    except (ValueError, KeyError):
        return None


@bp.route("/")
def index():
    return redirect(url_for("main.dashboard" if current_user.is_authenticated else "main.login"))


@bp.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        if not username or not password:
            flash("Username and password are required.")
        elif User.query.filter_by(username=username).first():
            flash("Username already taken.")
        else:
            profile = request.form.get("profile_type", "salaried")
            u = User(username=username, profile_type=profile if profile in PROFILES else "salaried")
            u.set_password(password)
            db.session.add(u)
            db.session.commit()
            login_user(u)
            return redirect(url_for("main.dashboard"))
    return render_template("register.html", profiles=PROFILES)


@bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        u = User.query.filter_by(username=request.form.get("username", "").strip()).first()
        if u and u.check_password(request.form.get("password", "")):
            login_user(u)
            return redirect(url_for("main.dashboard"))
        flash("Invalid credentials.")
    return render_template("login.html")


@bp.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("main.login"))


@bp.route("/dashboard")
@login_required
def dashboard():
    year, month = _ym()
    summary = monthly_summary(current_user.id, year, month)
    recent = (Expense.query.filter_by(user_id=current_user.id)
              .order_by(Expense.date.desc(), Expense.id.desc()).limit(10).all())
    return render_template("dashboard.html", s=summary, recent=recent,
                           goals=current_user.goals, categories=CATEGORIES,
                           today=date.today().isoformat())


@bp.route("/income", methods=["POST"])
@login_required
def add_income():
    amount = _positive_amount()
    if amount is None:
        flash("Enter a valid positive amount.")
    else:
        db.session.add(Income(user_id=current_user.id, amount=amount,
                              source=request.form.get("source", "Salary"),
                              date=_parse_date(request.form.get("date"))))
        db.session.commit()
    return redirect(url_for("main.dashboard"))


@bp.route("/expense", methods=["POST"])
@login_required
def add_expense():
    amount = _positive_amount()
    if amount is None:
        flash("Enter a valid positive amount.")
    else:
        category = request.form.get("category", "Other")
        db.session.add(Expense(user_id=current_user.id, amount=amount,
                               category=category if category in CATEGORIES else "Other",
                               description=request.form.get("description", ""),
                               date=_parse_date(request.form.get("date"))))
        db.session.commit()
    return redirect(url_for("main.dashboard"))


@bp.route("/expense/<int:eid>/delete", methods=["POST"])
@login_required
def delete_expense(eid):
    e = db.session.get(Expense, eid)
    if e and e.user_id == current_user.id:
        db.session.delete(e)
        db.session.commit()
    return redirect(url_for("main.dashboard"))


@bp.route("/goals", methods=["POST"])
@login_required
def add_goal():
    target = _positive_amount("target")
    if target is None:
        flash("Enter a valid target amount.")
    else:
        db.session.add(Goal(user_id=current_user.id, name=request.form.get("name", "Goal"), target_amount=target))
        db.session.commit()
    return redirect(url_for("main.dashboard"))


@bp.route("/goals/<int:gid>/contribute", methods=["POST"])
@login_required
def contribute(gid):
    g = db.session.get(Goal, gid)
    amount = _positive_amount()
    if g and g.user_id == current_user.id and amount is not None:
        g.saved_amount += amount
        db.session.commit()
    return redirect(url_for("main.dashboard"))


def _build_report(year, month):
    summary = monthly_summary(current_user.id, year, month)
    base = income_baseline(current_user.id, year, month, current_user.profile_type)
    budget = generate_budget(base, current_user.profile_type)
    flags = detect_overspending(summary, budget)
    return {
        "summary": summary, "budget": budget, "flags": flags,
        "advice": get_advice(summary, budget, flags, current_user.profile_type),
        "emergency_fund_target": emergency_fund_target(summary),
        "lean_months": lean_months(current_user.id, year, month) if current_user.profile_type == "freelancer" else [],
        "budget_base_income": base,
    }


@bp.route("/report")
@login_required
def report():
    year, month = _ym()
    return render_template("report.html", r=_build_report(year, month), year=year, month=month)


@bp.route("/api/report")
@login_required
def api_report():
    year, month = _ym()
    return jsonify(_build_report(year, month))
