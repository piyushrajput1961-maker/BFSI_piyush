from datetime import date, datetime
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()

CATEGORIES = ["Rent", "Food", "Transport", "Utilities", "Education",
              "Healthcare", "Groceries", "Entertainment", "Shopping",
              "Project Expenses", "Other"]

# Essentials vs discretionary, used by the budget engine
ESSENTIAL = {"Rent", "Food", "Transport", "Utilities", "Education",
             "Healthcare", "Groceries", "Project Expenses"}

PROFILES = ["salaried", "student", "freelancer", "household"]


class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    profile_type = db.Column(db.String(20), default="salaried")
    incomes = db.relationship("Income", backref="user", lazy=True, cascade="all, delete")
    expenses = db.relationship("Expense", backref="user", lazy=True, cascade="all, delete")
    goals = db.relationship("Goal", backref="user", lazy=True, cascade="all, delete")

    def set_password(self, pw):
        self.password_hash = generate_password_hash(pw)

    def check_password(self, pw):
        return check_password_hash(self.password_hash, pw)


class Income(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    source = db.Column(db.String(100), default="Salary")
    date = db.Column(db.Date, default=date.today)


class Expense(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    category = db.Column(db.String(50), nullable=False)
    description = db.Column(db.String(200), default="")
    date = db.Column(db.Date, default=date.today)


class Goal(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    target_amount = db.Column(db.Float, nullable=False)
    saved_amount = db.Column(db.Float, default=0.0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    @property
    def progress(self):
        return min(100, round(self.saved_amount / self.target_amount * 100, 1)) if self.target_amount else 0
