import pytest
from app import create_app
from app.analysis import generate_budget, detect_overspending, monthly_summary
from app.models import db, User, Income, Expense


class TestConfig:
    TESTING = True
    SECRET_KEY = "test"
    SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"
    ANTHROPIC_API_KEY = ""


@pytest.fixture
def app():
    app = create_app(TestConfig)
    yield app


def test_budget_split_sums_to_income():
    b = generate_budget(1000, "salaried")
    assert b["needs"] + b["wants"] + b["savings"] == 1000


def test_summary_and_overspending(app):
    with app.app_context():
        u = User(username="a"); u.set_password("x")
        db.session.add(u); db.session.commit()
        from datetime import date
        d = date(2026, 3, 5)
        db.session.add_all([Income(user_id=u.id, amount=1000, date=d),
                            Expense(user_id=u.id, amount=700, category="Rent", date=d),
                            Expense(user_id=u.id, amount=400, category="Entertainment", date=d)])
        db.session.commit()
        s = monthly_summary(u.id, 2026, 3)
        assert s["savings"] == -100
        flags = detect_overspending(s, generate_budget(s["total_income"], "salaried"))
        assert any("over budget" in a for a in flags["alerts"])


def test_register_login_flow(app):
    c = app.test_client()
    r = c.post("/register", data={"username": "bob", "password": "pw", "profile_type": "student"})
    assert r.status_code == 302
    assert c.get("/dashboard").status_code == 200
    c.post("/expense", data={"amount": "50", "category": "Food"})
    assert c.get("/api/report").json["summary"]["total_expense"] == 50
